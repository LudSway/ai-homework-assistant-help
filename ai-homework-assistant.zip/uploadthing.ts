import { createUploadthing, type FileRouter } from 'uploadthing/next';

const f = createUploadthing();

export const uploadRouter = {
  uploadHomework: f({
    maxFileSize: '4MB',
    allowedFileTypes: ['image/*', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
  }).onUploadComplete(async ({ file }) => {
    console.log('Upload completed:', file);
  }),
};

export type OurFileRouter = typeof uploadRouter;
