'use client';
import { UploadButton } from '@uploadthing/react';
import { useState } from 'react';

export default function Upload() {
  const [response, setResponse] = useState('');

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h2 className="text-2xl mb-4 font-semibold">Upload Homework or Research Document</h2>
      <UploadButton
        endpoint="uploadHomework"
        onClientUploadComplete={(res) => setResponse('✅ Upload complete!')}
        onUploadError={(error) => setResponse('❌ Upload failed: ' + error.message)}
      />
      <div className="mt-6 p-4 bg-white rounded shadow text-gray-800 whitespace-pre-wrap">{response}</div>
    </div>
  );
}
