'use client';
import { useState } from 'react';

export default function Chat() {
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');

  const handleSubmit = async () => {
    const res = await fetch('/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt })
    });
    const data = await res.json();
    setResponse(data.reply);
  };

  return (
    <div className="min-h-screen p-6 bg-gray-100">
      <h2 className="text-2xl mb-4 font-semibold">Ask a Question</h2>
      <textarea
        value={prompt}
        onChange={(e) => setPrompt(e.target.value)}
        className="w-full p-4 rounded-md border mb-4"
        rows={4}
        placeholder="Type your assignment or question..."
      />
      <button onClick={handleSubmit} className="bg-blue-600 text-white px-6 py-2 rounded-lg">Submit</button>
      <div className="mt-6 p-4 bg-white rounded shadow text-gray-800 whitespace-pre-wrap">{response}</div>
    </div>
  );
}
