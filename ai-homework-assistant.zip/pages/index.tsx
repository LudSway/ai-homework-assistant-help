import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-r from-blue-100 to-purple-200 p-6">
      <h1 className="text-4xl font-bold text-gray-800 mb-4">AI Homework & Research Assistant</h1>
      <p className="text-lg text-gray-700 mb-8">Get instant help with assignments, homework, and research</p>
      <div className="space-x-4">
        <Link href="/chat"><button className="bg-blue-600 text-white px-4 py-2 rounded-xl shadow hover:bg-blue-700">Ask a Question</button></Link>
        <Link href="/upload"><button className="bg-purple-600 text-white px-4 py-2 rounded-xl shadow hover:bg-purple-700">Upload Homework</button></Link>
      </div>
    </main>
  );
}
